# mbf_w

### Menu ###
(+) Crack ID Publik

(+) Crack ID Follower

(+) lihat Hasil Crack

#### Perintah ###
$ pkg update && upgrade

$ pkg install git

$ pkg install python2

$ pip2 install requests

$ git clone https://github.com/r0zhak/mbf_w

$ cd mbf_w

$ python2 run.py

### Password ###
(name)
(first_name123)
(first_name1234)
(first_name12345)
(first_name123456)
(last_name123)
(last_name1234)
(last_name12345)
(last_name123456)

[!] Sebelum Crack / Jika Tidak Ada Hasil Gunakan Mode Pesawat 5 Detik.

